function tampilkanBilangan() {
  const nilaiKecil = parseInt(document.getElementById("nilaiKecil").value);
  const nilaiBesar = parseInt(document.getElementById("nilaiBesar").value);
  const jenisBilangan = document.getElementById("jenisBilangan").value;
  let hasil = "";

  if (nilaiKecil > nilaiBesar) {
    alert("Nilai terkecil harus lebih kecil dari nilai terbesar!");
    return;
  }

  for (let i = nilaiKecil; i <= nilaiBesar; i++) {
    if (jenisBilangan === "ganjil" && i % 2 !== 0) {
      hasil += i + " ";
    } else if (jenisBilangan === "genap" && i % 2 === 0) {
      hasil += i + " ";
    }
  }

  document.getElementById("hasil").innerText =
    hasil || "Tidak ada bilangan yang ditemukan.";
}
